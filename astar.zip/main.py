import matplotlib.pyplot as plt

import time
from networkx import nx
import test

start_time = time.time()

n = 100 # 10 nodes
m = 10000  # 20 edges

G = nx.gnm_random_graph(n, m)


for clique in nx.find_cliques(G):
    if list(clique).__len__() >= 7:
        print('node %s ' % clique)




#nx.draw(G)
#plt.show()



