import numpy
import random

def cal_population_fitness(population):
    fitness = []
    for chromosome in population:
        ones_count = 0
        for x in chromosome:
            if x == 1:
                ones_count += 1
        fitness.append(ones_count)
    return fitness

def cal_chromosome_fitness(chromosome):

    ones_count = 0
    for x in chromosome:
        if x == 1:
            ones_count += 1
    return ones_count


def is_same_genes(chromosome1, chromosome2):
    index = 0
    for x in chromosome1:
        if chromosome1[index] != chromosome2[index]:
            return False
        index += 1
    return True


def select_mating_pool(pop, fitness):
    population_size = list(pop).__len__()
    if random.randint(0, 100) < 5:  # first parent select random chance
        parent1_index = random.randint(0, population_size - 1)
    else: # select fittest parent
        fittest_index = 0
        highest_fitness = fitness[0]
        index = 0
        for x in fitness:
            if x > highest_fitness:
                fittest_index = index
                highest_fitness = x
            index += 1
        parent1_index = fittest_index

    if random.randint(0, 100) < 5:  # second parent select random chance
        parent2_index = random.randint(0, population_size - 1)
        while parent2_index == parent1_index:
            parent2_index = random.randint(0, population_size - 1)

    else: # select fittest parent
        fittest_index = 0
        highest_fitness = fitness[0]
        index = 0
        for x in fitness:
            if x >= highest_fitness and index != parent1_index:
                fittest_index = index
                highest_fitness = x
            index += 1
        parent2_index = fittest_index

    index = 0
    while index < population_size and is_same_genes(pop[parent1_index], pop[parent2_index]):
        parent2_index = index
        index += 1

    if parent1_index == parent2_index:
        parent2_index = 0
    # print(f"p1: {parent1_index}, p2: {parent2_index}")

    return pop[parent1_index], pop[parent2_index]



def crossover(parent1, parent2):
    crossover_index = random.randint(0, parent1.__len__())

    child1 = []
    child2 = []

    index = 0
    for k in parent1:
        if index >= crossover_index:
            child1.append(parent2[index])
            child2.append(parent1[index])
        else:
            child1.append(parent1[index])
            child2.append(parent2[index])
        index += 1
    return child1, child2


def mutation(chromosome):
    zeros_count = 0
    for x in chromosome:
        if x == 0:
            zeros_count += 1

    removed_offset = random.randint(0, zeros_count)
    index = 0
    for x in chromosome:
        if removed_offset == 0:
            chromosome[index] = 1

        if x == 1:
            removed_offset -= 1
        index += 1

    return chromosome

