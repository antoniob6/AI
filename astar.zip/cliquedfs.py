import matplotlib.pyplot as plt
import time
from networkx import nx
import numpy

import os
import psutil

# process = psutil.Process(os.getpid())
#
# print(process.memory_info().rss)
start_time = time.time()

class SearchNode:
    def __init__(self, parent_search_node, curClique, lastNode, level, heuristic = 0, path_cost=0):
        self.parentNode = parent_search_node
        self.curClique = curClique
        self.lastNode = lastNode
        self.level = level
        self.heuristic = heuristic
        self.path_cost = path_cost

    def solution(self):
        return


class Stats:
    def __init__(self, clique, max_fringe, number_of_visits, time):
        self.clique = clique
        self.max_fringe = max_fringe
        self.number_of_visits = number_of_visits
        self.time = time
    def print(self):
        print(f"time: {(time.time() - start_time)},steps: {self.number_of_visits}, max fringe: {self.max_fringe}, first biggest clique: {self.clique} ")





class CliqueProblem:

    def getStartState(self):
        return SearchNode(None, [], None, 0)

    def getSuccessors(self, g, node, calc_heuristic = False):
        successors = []
        if node.lastNode is None:  # start state successors
            for n1 in g.nodes:
                new_clique = []
                new_clique.append(n1)
                successors.insert(0, SearchNode(node, new_clique, n1, 1))
            return successors

        neighbors = g.neighbors(node.lastNode)
        for n1 in neighbors:
            # order doesn't matter in cliques so we only check increasing order
            if node.lastNode < n1 and is_clique(g, node.curClique, n1):
                new_clique = []
                for n2 in node.curClique:
                    new_clique.append(n2)
                new_clique.append(n1)
                successors.insert(0, SearchNode(node, new_clique, n1, node.level + 1))

        if calc_heuristic:
            for s1 in successors:
                s1.heuristic = list(g.neighbors(s1.lastNode)).__len__()

        return successors

    def is_goal_state(self, g, state_node):
        if state_node.curClique.__len__() == g.nodes.__len__():
            return True
        return False

    # finds if the new node still defines a clique
    # in order to save resources we only check the old ones with the newly added node
def is_clique(g, old_nodes, new_node):
    for n1 in old_nodes:

        if not g.has_edge(n1, new_node):
            return False
    return True


def priorityInsert(fringe, state):
    index = 0
    store_index = 0
    for s in fringe:
        if state.heuristic >= s.heuristic:
            store_index = index
            break
        index += 1

    fringe.insert(store_index, state)


def astarSearch(g, problem):
    results = ""
    start_time = time.time()
    old_clique_len = 0
    stagnation = 0
    old_level = 0
    closed = set()  # visited nodes closed set
    fringe = []  # Queue to keep the problem nodes in
    max_fringe_len = 0
    index = 0
    current_state = problem.getStartState()  # current state

    stats1 = Stats(current_state.curClique, max_fringe_len, index, 0)
    fringe.append(current_state) # starts the graph search

    while True:
        index += 1
        cur_fringe_len = fringe.__len__()
        if cur_fringe_len > max_fringe_len:
            max_fringe_len = cur_fringe_len

        if cur_fringe_len <= 0:
            print("reached empty fringe")
            results += "fringe empty \n"
            return stats1, results

        state_node = fringe.pop()  # stores most recent node
        if state_node.level > old_level:
            old_level = state_node.level
            # print("new level ", old_level)

        process = psutil.Process(os.getpid())

        if process.memory_info().rss > 3000000000:
            print("reached empty fringe")
            results += "memory limit reached\n"

            return stats1, results

        cur_clique_len = state_node.curClique.__len__()
        if cur_clique_len > old_clique_len:
            results += f"{cur_clique_len},{max_fringe_len}, {index},"
            results += f"{process.memory_info().rss/1000000},{(time.time() - start_time)}, {state_node.curClique}\n"

            stats1 = Stats(current_state.curClique, max_fringe_len, index, (time.time() - start_time))
            #print(f"new bigger clique {cur_clique_len}, max fringe {max_fringe_len}, steps {index},"
            #      , f"memory usage {process.memory_info().rss}, time {(time.time() - start_time)}")


            current_state = state_node
            stagnation = 0
            old_clique_len = cur_clique_len

        # if stagnation > stagnation_limit:  #
        #     print("we have stagnated")
        #     stats = Stats(current_state.curClique, 0, index)
        #     return stats

        if problem.is_goal_state(g, state_node): # not necessary because we're looking for best solution
            print("reached goal state")
            results += "goal reached\n"
            return stats1, results

        stagnation += 1

        if state_node not in closed:
            closed.add(state_node)  # adds recent visited node to closed set
            for nextState in problem.getSuccessors(g, state_node, True):
                priorityInsert(fringe, nextState)

    print("while ended")





def breadthFirstSearch(g, problem):
    results = ""
    start_time = time.time()
    old_clique_len = 0
    stagnation = 0
    old_level = 0
    closed = set()  # visited nodes closed set
    fringe = []  # Queue to keep the problem nodes in
    max_fringe_len = 0
    index = 0
    current_state = problem.getStartState()  # current state

    stats1 = Stats(current_state.curClique, max_fringe_len, index, 0)
    fringe.append(current_state) # starts the graph search

    while True:
        index += 1
        cur_fringe_len = fringe.__len__()
        if cur_fringe_len > max_fringe_len:
            max_fringe_len = cur_fringe_len

        if cur_fringe_len <= 0:
            print("reached empty fringe")
            results += "fringe empty \n"
            return stats1, results

        state_node = fringe.pop()  # stores most recent node
        if state_node.level > old_level:
            old_level = state_node.level
            # print("new level ", old_level)

        process = psutil.Process(os.getpid())

        if process.memory_info().rss > 3000000000:
            print("reached empty fringe")
            results += "memory limit reached\n"

            return stats1, results

        cur_clique_len = state_node.curClique.__len__()
        if cur_clique_len > old_clique_len:
            results += f"{cur_clique_len},{max_fringe_len}, {index},"
            results += f"{process.memory_info().rss/1000000},{(time.time() - start_time)}, {state_node.curClique}\n"

            stats1 = Stats(current_state.curClique, max_fringe_len, index, (time.time() - start_time))
            #print(f"new bigger clique {cur_clique_len}, max fringe {max_fringe_len}, steps {index},"
            #      , f"memory usage {process.memory_info().rss}, time {(time.time() - start_time)}")


            current_state = state_node
            stagnation = 0
            old_clique_len = cur_clique_len

        # if stagnation > stagnation_limit:  #
        #     print("we have stagnated")
        #     stats = Stats(current_state.curClique, 0, index)
        #     return stats

        if problem.is_goal_state(g, state_node): # not necessary because we're looking for best solution
            print("reached goal state")
            results += "goal reached\n"
            return stats1, results

        stagnation += 1

        if state_node not in closed:
            closed.add(state_node)  # adds recent visited node to closed set
            for nextState in problem.getSuccessors(g, state_node):
                fringe.insert(fringe.__len__(), nextState)

    print("while ended")


def depthFirstSearch(g, problem, level_limit=0):
    results = ""

    start_time = time.time()
    old_clique_len = 0
    stagnation = 0
    old_level = 0
    closed = set()  # visited nodes closed set
    fringe = []  # Queue to keep the problem nodes in
    max_fringe_len = 0
    index = 0
    current_state = problem.getStartState()  # current state
    fringe.append(current_state) # starts the graph search
    stats1 = Stats(current_state.curClique, max_fringe_len, index, 0)

    while True:
        index += 1
        cur_fringe_len = fringe.__len__()
        if cur_fringe_len > max_fringe_len:
            max_fringe_len = cur_fringe_len

        if cur_fringe_len <= 0:
            print("reached empty fringe")
            results += "fringe empty \n"
            return stats1, results

        state_node = fringe.pop()  # stores most recent node
        if state_node.level > old_level:
            old_level = state_node.level
            # print("new level ", old_level)

        process = psutil.Process(os.getpid())

        if process.memory_info().rss > 3000000000:
            print("reached empty fringe")
            results += "memory limit reached\n"


            return stats1, results

        cur_clique_len = state_node.curClique.__len__()
        if cur_clique_len > old_clique_len:
            results += f"{cur_clique_len},{max_fringe_len}, {index},"
            results += f"{process.memory_info().rss/1000000},{(time.time() - start_time)}, {state_node.curClique}\n"
            stats1 = Stats(current_state.curClique, max_fringe_len, index, (time.time() - start_time))


            #print(f"new bigger clique {cur_clique_len}, max fringe {max_fringe_len}, steps {index},"
            #      , f"memory usage {process.memory_info().rss}, time {(time.time() - start_time)}")


            current_state = state_node
            stagnation = 0
            old_clique_len = cur_clique_len

        # if stagnation > stagnation_limit:  #
        #     print("we have stagnated")
        #     stats = Stats(current_state.curClique, 0, index)
        #     return stats

        if problem.is_goal_state(g, state_node): # not necessary because we're looking for best solution
            print("reached goal state")
            results += "goal reached\n"

            return stats1, results

        stagnation += 1

        if state_node not in closed:
            closed.add(state_node)  # adds recent visited node to closed set
            for nextState in problem.getSuccessors(g, state_node):
                if level_limit is 0 or nextState.level <= level_limit:
                    fringe.insert(0, nextState)

    print("while ended")





def ida(g, problem):
    start_time1 = time.time()
    level_limit = 2
    results1 = ""

    biggest_clique_size = 0;
    stagnating = False
    while not stagnating:
        stagnating = True
        results1 += f"IDA level: {level_limit} \n"
        stats1, results2 = depthFirstSearch(g, problem, level_limit)
        results1 += results2
        if list(stats1.clique).__len__() > biggest_clique_size:
            biggest_clique_size = list(stats1.clique).__len__()
            stagnating = False
        level_limit += 1

    # print(f"ida clique: {list(stats1.clique).__len__()}")
    results1 += "no improvement \n"
    stats1.time = (time.time() - start_time1)
    return stats1, results1





def do_graph_comparison():
    starting_nodes = 10
    starting_edges = 100



    stagnation_limit = 10000  # how many steps we take before we stagnate
    f = open('graph comparison.txt', 'w+')
    f.write("clique size, max fringe, visits, memory(MB), time \n")
    #between graph comparison
    for x in range(1, 3):
        graph_nodes_num = starting_nodes * (10 ** x)
        graph_edges_num = starting_edges * (10 ** x)

        G = nx.gnm_random_graph(graph_nodes_num, graph_edges_num)

        f.write(f"{graph_nodes_num} nodes, and {graph_edges_num} edges\n bfs \n")
        start_time = time.time()
        stats, results = breadthFirstSearch(G, CliqueProblem())
        f.write(results)

        f.write(f"dfs  \n")
        start_time = time.time()
        stats, results = depthFirstSearch(G, CliqueProblem())
        f.write(results)

        f.write(f"ida  \n")
        start_time = time.time()
        stats, results = ida(G, CliqueProblem())
        f.write(results)

        f.write(f"a star  \n")
        start_time = time.time()
        stats, results = astarSearch(G, CliqueProblem())
        f.write(results)

        print(f"iteration: {x}")
        if stats:
            stats.print()

    f.close()

def do_average_comparison():
    starting_nodes = 10
    starting_edges = 100

    time_samples = []
    clique_size_samples = []
    max_fringe_samples = []
    visits_samples = []

    time_samples1 = []
    clique_size_samples1 = []
    max_fringe_samples1 = []
    visits_samples1 = []

    time_samples2 = []
    clique_size_samples2 = []
    max_fringe_samples2 = []
    visits_samples2 = []

    time_samples3 = []
    clique_size_samples3 = []
    max_fringe_samples3 = []
    visits_samples3 = []
    stagnation_limit = 10000  # how many steps we take before we stagnate
    kk = open('avgcomp.txt', 'w+')

    #between graph comparison
    samples_count = 0
    kk.write(f"average testing {samples_count} samples \n ")
    kk.write(f"nodes, edges, average clique,average time,average fringe, average visits, test type\n")
    for x in range(1, 2):
        for iii in range(1, samples_count):
            graph_nodes_num = starting_nodes * (10 ** x)
            graph_edges_num = starting_edges * (15 ** x)
            start_time = time.time()
            G = nx.gnm_random_graph(graph_nodes_num, graph_edges_num)

            stats, results = depthFirstSearch(G, CliqueProblem())
            time_samples.append(stats.time)
            clique_size_samples.append(list(stats.clique).__len__())
            max_fringe_samples.append(stats.max_fringe)
            visits_samples.append(stats.number_of_visits)

            stats, results = ida(G, CliqueProblem())
            time_samples1.append(stats.time)
            clique_size_samples1.append(list(stats.clique).__len__())
            max_fringe_samples1.append(stats.max_fringe)
            visits_samples1.append(stats.number_of_visits)

            stats, results = breadthFirstSearch(G, CliqueProblem())
            time_samples2.append(stats.time)
            clique_size_samples2.append(list(stats.clique).__len__())
            max_fringe_samples2.append(stats.max_fringe)
            visits_samples2.append(stats.number_of_visits)

            stats, results = astarSearch(G, CliqueProblem())
            time_samples3.append(stats.time)
            clique_size_samples3.append(list(stats.clique).__len__())
            max_fringe_samples3.append(stats.max_fringe)
            visits_samples3.append(stats.number_of_visits)


        kk.write(f"{graph_nodes_num},{graph_edges_num},")
        kk.write(f"{numpy.average(clique_size_samples)},{numpy.average(time_samples)}")
        kk.write(f",{numpy.average(max_fringe_samples)},{numpy.average(visits_samples)},dfs\n")
        kk.write(f"{graph_nodes_num},{graph_edges_num},")
        kk.write(f"{numpy.average(clique_size_samples1)},{numpy.average(time_samples1)}")
        kk.write(f",{numpy.average(max_fringe_samples1)},{numpy.average(visits_samples1)},ida\n")
        kk.write(f"{graph_nodes_num},{graph_edges_num},")
        kk.write(f"{numpy.average(clique_size_samples2)},{numpy.average(time_samples2)}")
        kk.write(f",{numpy.average(max_fringe_samples2)},{numpy.average(visits_samples2)},bfs\n")
        kk.write(f"{graph_nodes_num},{graph_edges_num},")
        kk.write(f"{numpy.average(clique_size_samples3)},{numpy.average(time_samples3)}")
        kk.write(f",{numpy.average(max_fringe_samples3)},{numpy.average(visits_samples3)},astar\n")

    kk.close()




#do_graph_comparison()
do_average_comparison()

# G = nx.gnm_random_graph(10, 20)
# start_time = time.time()
# stats, results = breadthFirstSearch(G, CliqueProblem())
# print(results)


# if G.number_of_edges() < 100 and G.number_of_nodes() < 20:
#     nx.draw(G, with_labels=True, font_weight='bold')
#     plt.show()


# def depthFirstSearch(problem):
#     """
#     Search the deepest nodes in the search tree first.
#     Your search algorithm needs to return a list of actions that reaches the
#     goal. Make sure to implement a graph search algorithm.
#     To get started, you might want to try some of these simple commands to
#     understand the search problem that is being passed in:
#     print "Start:", problem.getStartState()
#     print "Is the start a goal?", problem.isGoalState(problem.getStartState())
#     print "Start's successors:", problem.getSuccessors(problem.getStartState())
#     """
#     "*** YOUR CODE HERE ***"
#     closed = set()  # visited nodes closed set
#     fringe = util.Stack()  # stack to keep the problem nodes in
#     currentState = problem.getStartState()  # current state
#     node = util.Node(currentState)
#     fringe.push(node)  # starts the graph search
#     while fringe:
#         if fringe.isEmpty():
#             return False
#         node = fringe.pop()  # stores most recent node
#         if problem.isGoalState(node.state):
#             return node.solution()  # return current node
#         if node.state not in closed:
#             closed.add(node.state)  # adds recent visited node to closed set
#             for nextState, act, cost in problem.getSuccessors(node.state):
#                 childnode = util.Node(nextState, node, act)
#                 fringe.push(childnode)
#
#

# def uniformCostSearch(problem):
#     """Search the node of least total cost first."""
#     "*** YOUR CODE HERE ***"
#     closed = set()  # visited nodes closed set
#     fringe = util.PriorityQueue()  # Priority Queue to give priority for node with least cost
#     currentState = problem.getStartState()  # current state
#     node = util.Node(currentState)
#     fringe.push(node, node.path_cost)  # starts the graph search with priority of parent
#     nodePriority = node.path_cost
#     while fringe:
#         if fringe.isEmpty():
#             return False
#         node = fringe.pop()  # stores most recent node
#         if problem.isGoalState(node.state):
#             return node.solution()  # return current node
#         if node.state not in closed:
#             closed.add(node.state)  # adds recent visited node to closed set
#             for nextState, action, cost in problem.getSuccessors(node.state):  # lists through
#                 childnode = util.Node(nextState, node, action,
#                                       cost + node.path_cost)  # makes child node with cumulative cost
#                 priority = nodePriority + childnode.path_cost  # updates priority
#                 fringe.push(childnode, priority)  # pushes new node with priority
#
#
# def aStarSearch(problem, heuristic=nullHeuristic):
#     """Search the node that has the lowest combined cost and heuristic first."""
#     "*** YOUR CODE HERE ***"
#     closed = set()  # visited nodes closed set
#     fringe = util.PriorityQueue()  # Priority Queue to give priority for node with least cost
#     currentState = problem.getStartState()  # current state
#     node = util.Node(currentState)
#     h = heuristic(currentState, problem)
#     fringe.push(node, h)  # starts the graph search with priority of parent
#     while fringe:
#         if fringe.isEmpty():
#             return False
#         node = fringe.pop()  # stores most recent node
#         if problem.isGoalState(node.state):
#             return node.solution()  # return current node
#         if node.state not in closed:
#             closed.add(node.state)  # adds recent visited node to closed set
#             for nextState, action, cost in problem.getSuccessors(node.state):  # lists through
#                 h = heuristic(nextState, problem)
#                 childnode = util.Node(nextState, node, action,
#                                       cost + node.path_cost)  # makes child node with cumulative cost
#                 priority = h + childnode.path_cost  # updates priority
#                 fringe.push(childnode, priority)  # pushes new node with priority








