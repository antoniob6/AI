import numpy
import GA as ga
import random
import matplotlib.pyplot as plt
from networkx import nx

"""
The y=target is to maximize this equation ASAP:
    y = w1x1+w2x2+w3x3+w4x4+w5x5+6wx6
    where (x1,x2,x3,x4,x5,x6)=(4,-2,3.5,5,-11,-4.7)
    What are the best values for the 6 weights w1 to w6?
    We are going to use the genetic algorithm for the best possible values after a number of generations.
"""

def insert_in_population(popultaion, child):
    pop_fitness = ga.cal_population_fitness(popultaion)
    child_fitness = ga.cal_chromosome_fitness(child)

    index1 = 0
    for x1 in pop_fitness:
        if x1 < child_fitness:
            popultaion[index1] = child
            return popultaion

        index1 += 1
    return popultaion


def is_clique(g, nodes):
    for n1 in nodes:
        for n2 in nodes:
            if n1 != n2:
                if not G.has_edge(n1, n2):
                    return False
    return True
def is_clique_chromosome(g, chromosome):

    nodes = chromosome_to_nodes(g, chromosome)
    if not is_clique(g, nodes):
       # print(f"not clique {chromosome}")
        return False
    #print(f"yes clique {chromosome}")
    return True

def chromosome_to_nodes(g,chromosome):
    nodes = set()
    index = 0
    for x in chromosome:
        if x == 1:
            nodes.add(list(G.nodes).__getitem__(index))
        index += 1
    return nodes


def remove_weakest_node(chromosome):
    ones_count = 0
    for x in chromosome:
        if x == 1:
            ones_count += 1

    removed_offset = random.randint(0, ones_count)
    #print(f"random offset: {ones_count}")

    index = 0
    for x in chromosome:
        if removed_offset == 0:
            chromosome[index] = 0

        if x == 1:
            removed_offset -= 1
        index += 1

    return chromosome

def optimizer(g, chromosome):
    while not is_clique_chromosome(g, chromosome):
        #print("removing link")
        chromosome = remove_weakest_node(chromosome)







"""
Genetic algorithm parameters:
    Mating pool size
    Population size
"""
sol_per_pop = 20
num_parents_mating = 4
G = nx.gnm_random_graph(1000, 20000)



# Defining the population size.
pop_size = (sol_per_pop,
            G.nodes.__len__())  # The population will have sol_per_pop chromosome where each chromosome has num_weights genes.
# Creating the initial population.

new_population = numpy.random.randint(low=0, high=2, size=pop_size)


#print(new_population)
#print("optimizing start")
for chromosome in new_population:
    optimizer(G, chromosome)

#print("optimizing done")
#print(new_population)




"""
new_population[0, :] = [2.4,  0.7, 8, -2,   5,   1.1]
new_population[1, :] = [-0.4, 2.7, 5, -1,   7,   0.1]
new_population[2, :] = [-1,   2,   2, -3,   2,   0.9]
new_population[3, :] = [4,    7,   12, 6.1, 1.4, -4]
new_population[4, :] = [3.1,  4,   0,  2.4, 4.8,  0]
new_population[5, :] = [-2,   3,   -7, 6,   3,    3]
"""

best_outputs = []
num_generations = 5
for generation in range(num_generations):
    #print("Generation : ", generation)
    # Measuring the fitness of each chromosome in the population.
    fitness = ga.cal_population_fitness(new_population)
   # print("Fitness")
   # print(fitness)
    #print(new_population)

    best_outputs.append(numpy.max(ga.cal_population_fitness(new_population)))
    parent1, parent2 = ga.select_mating_pool(new_population, fitness)

    child1, child2 = ga.crossover(parent1, parent2)

    child1 = ga.mutation(child1)
    #child2 = ga.mutation(child2)

    optimizer(G, child1)
    optimizer(G, child2)

    new_population = insert_in_population(new_population, child1)
    new_population = insert_in_population(new_population, child2)

# Getting the best solution after iterating finishing all generations.
# At first, the fitness is calculated for each solution in the final generation.
fitness = ga.cal_population_fitness(new_population)
# Then return the index of that solution corresponding to the best fitness.


fittest_index = 0
highest_fitness = fitness[0]
index = 0
for x in fitness:
    if x > highest_fitness:
        fittest_index = index
        highest_fitness = x
    index += 1


print("Best solution : ", new_population[fittest_index, :])
print("Best solution fitness : ", fitness[fittest_index])

if G.number_of_edges() < 100 and G.number_of_nodes() < 20:
    nx.draw(G, with_labels=True, font_weight='bold')
    plt.show()


import matplotlib.pyplot

matplotlib.pyplot.plot(best_outputs)
matplotlib.pyplot.xlabel("Iteration")
matplotlib.pyplot.ylabel("Fitness")
matplotlib.pyplot.show()